// export function helloWorld () { // export as function
export default function helloWorld () {
    console.log('Hello from events!');
};